num = 6

print(num)